<?php
    $db = mysql_connect ("olimp","root","");
    mysql_select_db ("olimpiada",$db);
  ?>